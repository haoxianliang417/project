/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50714
Source Host           : localhost:3306
Source Database       : zhongjiu

Target Server Type    : MYSQL
Target Server Version : 50714
File Encoding         : 65001

Date: 2017-07-14 17:27:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for recommend
-- ----------------------------
DROP TABLE IF EXISTS `recommend`;
CREATE TABLE `recommend` (
  `goodsid` int(11) NOT NULL AUTO_INCREMENT,
  `imgUrl` varchar(255) NOT NULL,
  `classify` int(11) NOT NULL,
  `bigImg` varchar(255) NOT NULL,
  `goodstitle` varchar(255) CHARACTER SET utf8 NOT NULL,
  `other` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `price` float(255,2) NOT NULL,
  `saleout` int(11) DEFAULT NULL,
  `discuss` int(11) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  PRIMARY KEY (`goodsid`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of recommend
-- ----------------------------
INSERT INTO `recommend` VALUES ('1', '201703101457379373680.jpg', '0', '1.png', '52°汾酒集团清典荣耀 850ml（2瓶装）', '荣耀时刻，就要与朋友尽情畅饮！', '198.00', '766', '0', '4');
INSERT INTO `recommend` VALUES ('2', '201703101458282942570.jpg', '0', '2.png', '【礼盒】48°天佑德青稞酒福之德礼盒装500ml*2', '', '648.00', '85', '9', '5');
INSERT INTO `recommend` VALUES ('3', '201703101458343938680.jpg', '0', '3.png', '【礼盒】马克斯威双支礼盒 750ml*2', '美国原装进口，精美双支礼盒', '199.00', '2', '1', '5');
INSERT INTO `recommend` VALUES ('4', '201703101458462654880.jpg', '0', '4.png', '奥德小教堂干红葡萄酒 750ml（2瓶装） 慕尼黑', '', '159.00', '158', '1', '5');
INSERT INTO `recommend` VALUES ('5', '201703101458499938950.jpg', '0', '5.png', '华夏长城干红葡萄酒 750ml（6瓶装）', '松木礼箱 送礼佳品', '198.00', '199', '417', '4');
INSERT INTO `recommend` VALUES ('6', '201703101458556879050.jpg', '0', '6.png', '人头马特优香槟干邑XO 700ml', '', '1399.00', '156', '379', '4');
INSERT INTO `recommend` VALUES ('7', '201703141146412534670.jpg', '0', '7.png', '42度 天佑德青稞酒 海拔2600 500ml（2瓶装）', '', '176.00', '160', '139', '4');
INSERT INTO `recommend` VALUES ('8', '201703141146443578720.jpg', '0', '8.png', '46°天佑德青稞酒2800 500ml（2瓶装）', '海拔2800米高原青稞酿造', '229.00', '0', '0', '5');
INSERT INTO `recommend` VALUES ('9', '201703141146500050820.jpg', '0', '9.png', '46°天佑德青稞酒海拔3200 500ml', '', '188.00', '163', '70', '4');
INSERT INTO `recommend` VALUES ('10', '201703141147004883000.jpg', '0', '10.png', '45°天佑德青稞酒海拔3500 500ml', '', '248.00', '121', '152', '4');
INSERT INTO `recommend` VALUES ('11', '201703141147033275050.jpg', '1', '11.png', '48°天佑德青稞酒海拔3600 500ml', '', '288.00', '166', '75', '4');
INSERT INTO `recommend` VALUES ('12', '201703141147091775160.jpg', '1', '12.png', '45°天佑德生态三星 500ml (6瓶装）', '【在天佑德会场可领取满399减60元优惠券】天佑德生态美酒，高原青稞酿造，纯净天然健康', '399.00', '30', '7', '4');
INSERT INTO `recommend` VALUES ('13', '201703141147266651460.jpg', '1', '13.png', '48°天佑德青稞酒生态四星 500ml', '悠悠青稞酒，滴滴美酒香', '88.00', '130', '85', '4');
INSERT INTO `recommend` VALUES ('14', '201703141147289115500.jpg', '1', '14.png', '52°天佑德青稞酒生态五星 500ml', '', '148.00', '119', '0', '5');
INSERT INTO `recommend` VALUES ('15', '201703141147354635620.jpg', '1', '15.png', '40°天佑德橡木青稞酒500ML', '', '310.00', '114', '27', '5');
INSERT INTO `recommend` VALUES ('16', '201703141147377567660.jpg', '1', '16.png', '【礼盒】48°天佑德青稞酒福之德礼盒装500ml*2', '', '648.00', '85', '9', '5');
INSERT INTO `recommend` VALUES ('17', '201704072009377178530.jpg', '1', '17.png', '【礼盒】拉菲珍藏波尔多 750ml（2瓶装） 拉菲皮盒', '法国波尔多法定产区AOC', '239.00', '153', '70', '4');
INSERT INTO `recommend` VALUES ('18', '201704072012359417040.jpg', '1', '18.png', '尊尼获加红牌调配苏格兰威士忌 700ml（礼盒装）', '', '159.00', '95', '0', '5');
INSERT INTO `recommend` VALUES ('19', '201704121143421788430.jpg', '1', '19.png', '35°五粮液五粮醇金淡雅 500ml', '五粮液出品，浓香型白酒', '98.00', '153', '0', '5');
INSERT INTO `recommend` VALUES ('20', '201704121143486528540.jpg', '1', '20.png', '50°五粮液五粮醇蓝淡雅 500ml', '精工酿造 浓香淡雅', '109.00', '360', '342', '4');
INSERT INTO `recommend` VALUES ('21', '201704121143564996680.jpg', '2', '21.png', '52°金剑南K6 500ml', '【温馨提示：新旧包装交替发货，以收到的实物为准，不支持商品兑换】\r\n', '159.00', '1103', '1162', '4');
INSERT INTO `recommend` VALUES ('22', '201704121144025368780.jpg', '2', '22.png', '52°泸州老窖头曲 500ml', '泸州老窖头曲，浓香美酒典范', '69.00', '2599', '1191', '4');
INSERT INTO `recommend` VALUES ('23', '201704121144051576830.jpg', '2', '23.png', '52°泸州老窖 永盛烧坊蓝八系列 500ml', '', '89.00', '1166', '1086', '4');
INSERT INTO `recommend` VALUES ('24', '201704121144079032880.jpg', '2', '24.png', '53°茅台镇一道泓酱香传奇 1000ml （2瓶装）', '茅台镇出品，酱香型美酒', '109.00', '964', '186', '4');
INSERT INTO `recommend` VALUES ('25', '201704121144102432920.jpg', '2', '25.png', '67°衡水老白干蓝花瓷 500ml', '', '79.00', '737', '841', '4');
INSERT INTO `recommend` VALUES ('26', '201704121144164833030.jpg', '2', '26.png', '【包邮】50°古井贡酒年份原浆献礼 500ml', '【拼团商品不能使用优惠券，不能选择货到付款】古井年份酒，原浆优质酒', '79.00', '479', '360', '5');
INSERT INTO `recommend` VALUES ('27', '201704121144250321180.jpg', '2', '27.png', '52°牛栏山珍品十五年 400ml', '新老包装交替发货，商品以实物为准', '59.00', '513', '278', '4');
INSERT INTO `recommend` VALUES ('28', '201704121144426289490.jpg', '2', '28.png', '46°天润甘九道醇合家团圆 1000ml', '两斤大坛，优质白酒', '99.00', '1346', '1097', '4');
INSERT INTO `recommend` VALUES ('29', '201704121353237533100.jpg', '2', '29.png', 'bacardi百加得白朗姆酒 750ml', '【赠洋酒杯】激情畅饮，回味无穷', '59.00', '652', '13', '5');
INSERT INTO `recommend` VALUES ('30', '201704121353267329150.jpg', '2', '30.png', '百利甜爱尔兰 750ml', '奶油与威士忌 的巧妙融合', '79.00', '1632', '3', '5');
INSERT INTO `recommend` VALUES ('31', '201704121353290573190.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('32', '201704121353311633230.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('33', '201704121353367169330.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('34', '201704121353428477440.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('35', '201704121353495401550.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('36', '201704121353516149590.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('37', '201704121353535337620.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('38', '201704191101241283220.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('39', '201705031657054751560.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('40', '201705151042039711570.jpg', '3', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('41', '201703101458556879050.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('42', '201703101458343938680.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('43', '201703141147354635620.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('44', '201704072012359417040.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('45', '201704072009377178530.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('46', '201704121353290573190.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('47', '201704121353495401550.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('48', '201704121353516149590.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('49', '201704121353535337620.jpg', '4', '', '', null, '0.00', null, null, null);
INSERT INTO `recommend` VALUES ('50', '201705151042039711570.jpg', '4', '', '', null, '0.00', null, null, null);

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `account` varchar(32) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES ('1', '13632459713', 'e10adc3949ba59abbe56e057f20f883e', null);
SET FOREIGN_KEY_CHECKS=1;
